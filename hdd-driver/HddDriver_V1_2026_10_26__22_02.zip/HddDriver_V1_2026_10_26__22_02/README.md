# HDD Driver V1 — JLCPCB manufacturing notes

Board: hdd-driver (HDD Driver V1), 74 × 73 mm, 2 copper layers.

## Upload

Upload **`HddDriver_V1_2026_10_26__22_02_gerbers.zip`** at jlcpcb.com. It holds the Gerbers (Protel extensions) and the Excellon drill files (PTH and NPTH separate). The `gerbers/` folder has the same files unzipped.

## PCB order parameters

| Option | Value |
|---|---|
| Base material | FR-4 |
| Layers | 2 |
| Dimensions | 74 × 73 mm |
| PCB thickness | 1.6 mm |
| Outer copper weight | 1 oz |
| Surface finish | **ENIG**: the motor's spring contacts press on the three bare pads on the bottom side |
| Via covering | Tented |
| Mark on PCB (order number) | Remove, or accept JLCPCB's placement |
| Colour, silkscreen | Any |

Everything is within JLCPCB's standard 2-layer capabilities; only ENIG costs extra.

## Design minimums

- Track width 0.2 mm (widths used: 0.2 mm, 0.3 mm, 0.4 mm, 0.5 mm, 2 mm).
- Clearance 0.2 mm.
- Smallest drill 0.3 mm.
- Vias: 0.3 mm drill / 0.6 mm pad; through vias only.
- Plated holes: 0.8 mm, 1 mm, 1.1 mm, 1.3 mm, 2.4 mm, 3.2 mm.
- Non-plated holes: 1.1 mm.
- Mounting holes: 3 × M2, 4 × M3, plated.
- Finest pitch: TSSOP-8, 0.65 mm (U5, U6). No impedance control.

## Assembly (optional)

JLCPCB can place the SMD parts:

| Ref | Value | Side |
|---|---|---|
| C2 | 100nF | Top |
| C3 | 100nF | Top |
| C4 | 100nF | Top |
| C5 | 100nF | Top |
| C6 | 100nF | Top |
| C7 | 470pF | Top |
| C8 | 1uF | Top |
| D1 | SS54 | Top |
| D2 | B5819W | Top |
| D3 | BAV99 | Top |
| R1 | 100k | Top |
| R2 | 10k | Top |
| R6 | 22k | Top |
| R7 | 10k | Top |
| R8 | 10k | Top |
| RS1 | 20m | Top |
| RS2 | 20m | Top |
| RS3 | 20m | Top |
| U4 | INA181A2 | Top |
| U5 | INA240A1PW | Top |
| U6 | INA240A1PW | Top |

Upload `BOM-JLCPCB.csv` and `CPL-JLCPCB.csv` and order Economic PCBA, top side.

The INA181/INA240 amplifiers and the 20 mΩ shunts are Extended parts, so they add a feeder fee each; the quote lists which parts are Basic. Check stock before ordering.

Check the placement preview: the diodes (D1–D3) and the amplifiers (U4–U6) are polarised, and JLCPCB's rotation for SOT-23, SMA and TSSOP footprints sometimes differs from KiCad's. Pin 1 of each must match the silkscreen dot or bar.

Hand-soldered through-hole parts, not part of the JLCPCB order: C1 (470uF 25V), J1 (12V IN), J3 (VR coil), JP1 (VM select), U1 (WeAct STM32G474CEU6 Core Board), U2 (SimpleFOC Mini v1.0 (DRV8313)), U3 (MT3608 module, set to 12 V). The modules sit on 2.54 mm female headers. Trim their leads flush on the bottom side, which faces the drive's metal base. J2 (HDD motor contacts) is copper only: the spring pads and the screw-7 hole. `BOM-hdd-driver.csv` lists every part.

## Files

| File | What |
|---|---|
| `HddDriver_V1_2026_10_26__22_02_gerbers.zip` | Gerbers and drill files for upload |
| `gerbers/` | The same, unzipped; also the drill maps |
| `BOM-JLCPCB.csv`, `CPL-JLCPCB.csv` | JLCPCB assembly BOM (LCSC part numbers) and placement |
| `BOM-hdd-driver.csv` | Full BOM from the schematic |
| `hdd-driver-schematic.pdf` | Schematic |
| `hdd-driver-top.pdf`, `hdd-driver-bottom.pdf` | Copper, mask and silkscreen; the bottom is mirrored |
| `hdd-driver.step` | 3D model with the module models |
